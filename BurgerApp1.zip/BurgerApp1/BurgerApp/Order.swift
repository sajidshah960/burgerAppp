//
//  Order.swift
//  BurgerApp
//
//  Created by ieX Lab 1_4 on 21/06/2019.
//  Copyright © 2019 ieX Lab 1_1. All rights reserved.
//

import Foundation

struct Order: Codable {
    let ingredients: [Ingredient]
}
