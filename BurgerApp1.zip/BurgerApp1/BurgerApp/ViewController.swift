//
//  ViewController.swift
//  BurgerApp
//
//  Created by ieX Lab 1_1 on 19/06/2019.
//  Copyright © 2019 ieX Lab 1_1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var buttonLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func BookBurger(_ sender: Any) {
        let storyboard = UIStoryboard (name:"Main" , bundle:nil )
        let vc = storyboard.instantiateViewController(withIdentifier: "BurgerViewController")
        navigationController?.pushViewController(vc,animated:false)
    }
    
}

