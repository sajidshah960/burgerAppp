//
//  SelectionPersistenceServiceTests.swift
//  Burger BuilderTests
//
//  Created by Bushra Shahid on 6/17/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import XCTest
@testable import Burger_Builder

class SelectionPersistenceServiceTests: XCTestCase {

    private var service: SelectionPersistenceService?
    
    override func setUp() {
        service = SelectionPersistenceService(dataStore: MockDataStore())
    }

    override func tearDown() {
        service = nil
    }

    func testSavingIngredients() {
        let ingredientsToSave = Set([Ingredient(name: "Bushra"), Ingredient(name: "Shahid")])
        XCTAssertTrue(service!.saveSelectedIngredients(ingredientsToSave))
    }
    
    func testSavingEmptyIngredientsList() {
        let ingredientsToSave = Set<Ingredient>([])
        _ = service!.saveSelectedIngredients(ingredientsToSave)
        let savedIngredients = service!.loadSelectedIngredients()
        XCTAssertEqual(savedIngredients!.count, 0)
    }
    
    func testRetrievingSavedIngredients() {
        let ingredientsToSave = Set([Ingredient(name: "Bushra"), Ingredient(name: "Shahid")])
        _ = service!.saveSelectedIngredients(ingredientsToSave)
        let savedIngredients = service!.loadSelectedIngredients()
        XCTAssertNotNil(savedIngredients)
        XCTAssertEqual(savedIngredients, ingredientsToSave)
    }
    
    func testClearingSavedIngredients() {
        let ingredientsToSave = Set([Ingredient(name: "Bushra"), Ingredient(name: "Shahid")])
        _ = service!.saveSelectedIngredients(ingredientsToSave)
        service!.clearSavedSelectedIngredients()
        let savedIngredients = service!.loadSelectedIngredients()
        XCTAssertEqual(savedIngredients!.count, 0)
    }

}
