//
//  MockDataStore.swift
//  Burger BuilderTests
//
//  Created by Bushra Shahid on 6/17/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation
@testable import Burger_Builder

class MockDataStore: DataStoreProtocol {
    
    private var dataStore: [String: Codable] = [:]
    
    func storeData<T: Codable>(_ encodable: T, forKey key: DataStoreKey) -> Bool {
        dataStore[key.rawValue] = encodable
        return true
    }
    
    func retrieveData<T: Codable>(forKey key: DataStoreKey) -> T? {
        return dataStore[key.rawValue] as? T
    }
}
