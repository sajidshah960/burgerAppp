//
//  ViewController.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/2/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    // MARK: - View lifecycle
    
    // Called when the view is about to made visible. Default does nothing
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    // Called when the view is dismissed, covered or otherwise hidden. Default does nothing
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.isNavigationBarHidden = false
    }

    // MARK: - Actions
    
    /// Handle user action on 'Build a burger' button
    @IBAction func buildABurger() {
        // 1. Instantiate burger view controller
        let vc = BurgerViewController.instantiate()
        
        // 3. Push the instantiated view controller onto the navigation stack
        navigationController?.pushViewController(vc, animated: true)
    }
}

