//
//  Ingredient.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/3/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Encapsulates an ingredient
struct Ingredient: Hashable, Codable {
    let name: String
}
