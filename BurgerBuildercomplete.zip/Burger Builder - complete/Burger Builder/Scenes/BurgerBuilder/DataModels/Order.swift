//
//  Order.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/9/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Encapsulates an order
struct Order: Codable {
    let ingredients: [Ingredient]
}
