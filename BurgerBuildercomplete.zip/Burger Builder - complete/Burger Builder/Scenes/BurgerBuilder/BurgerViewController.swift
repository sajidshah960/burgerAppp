//
//  BurgerViewController.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/3/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import UIKit

class BurgerViewController: UITableViewController {
    
    /// Outlet connection to loading indicator
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    /// Outlet connection to order button
    @IBOutlet weak var orderButton: UIButton!
    
    /// List of ingredients that can be used to build burgers
    private let ingredients: [Ingredient] = IngredientProviderService().loadIngredients()
    
    /// List of selected ingredients for the burger being built
    private var selectedIngredients: Set<Ingredient> = [] {
        // Reload table view whenever the selected ingredients are updated
        didSet { tableView.reloadData() }
    }
    
    /// Service to save selection state
    private let selectionPersistenceService = SelectionPersistenceService(dataStore: DataStore())
    
    /// Service to create new orders
    private let orderCreationService = OrderCreationService(networking: Networking())
    
    // MARK: - Initializers
    
    static func instantiate() -> BurgerViewController {
        // 1. Get the storyboard where the burger view controller has been added
        let storyboard = UIStoryboard(name: "Burger", bundle: nil)
        
        // 2. Instantiate view controller using identifier set in the storyboard
        let vc = storyboard.instantiateViewController(withIdentifier: "BurgerViewController") as! BurgerViewController
        
        // 3. Return
        return vc
    }
    
    // MARK: - View lifecycle
    
    // Called after the view has been loaded. For view controllers created in code, this is after -loadView.
    // For view controllers unarchived from a nib, this is after the view is set.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Register table view cell class
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "reuseIdentifier")
        
        // Load previously selected ingredients in the table view, if any
        if let ingredients = selectionPersistenceService.loadSelectedIngredients() {
            selectedIngredients = ingredients
        }
        // The condition above can be written as following for brevity:
        // selectionPersistenceService.loadSelectedIngredients().flatMap { selectedIngredients = $0 }
    }
    
    // Called when the view is about to made visible. Default does nothing
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Save selection when app enters background
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: nil) {
            [weak self] _ in
            guard let `self` = self else { return }
            _ = self.selectionPersistenceService.saveSelectedIngredients(self.selectedIngredients)
        }
    }
    
    // Called when the view is dismissed, covered or otherwise hidden. Default does nothing
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ingredients.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // 1. Load a cell for the specified reuse identifier
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        
        // 2. Customise the loaded cell
        let ingredient = ingredients[indexPath.row]
        cell.textLabel?.text = ingredient.name
        updateSelection(cell: cell, isSelected: selectedIngredients.contains(ingredient))
        
        // 3. Return the cell to the table view to display
        return cell
    }
    
    // MARK: - Table view delegate
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 1. Get the selected cell from the table view
        guard let cell = tableView.cellForRow(at: indexPath) else {
            return assertionFailure("Selected cell cannot be nil.")
        }
        
        // 2. Load the selected ingredient
        let selectedIngredient = ingredients[indexPath.row]
        
        // 3. Find out if the ingredient was added or removed
        let isSelected = !selectedIngredients.contains(selectedIngredient)
        
        // 4. Update UI to reflect the result of addition/removal
        updateSelection(cell: cell, isSelected: isSelected)
        
        // 5. Update the list of selected ingredients to save the change in selection
        updateSelection(ingredient: selectedIngredient, isSelected: isSelected)
        
        // 6. Deselect the cell from the table view
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    // MARK: - Actions
    
    /// Handles touch up inside interaction with the order button
    @IBAction func order() {
        // 1. Show visual indication of async activity
        showLoading(true)
        
        // 2. Place order
        orderCreationService.placeOrder(ingredients: selectedIngredients) { [weak self] response in
            
            // a. Hide loading indicatiors
            self?.showLoading(false)
            
            switch response {
            case .created:
                // b. Restart the burger builder
                self?.navigationController?.popViewController(animated: true)
                // c. Clear saved selected ingredients
                self?.selectionPersistenceService.clearSavedSelectedIngredients()

            case .failed:
                // d. Show error and stay on the burger builder
                self?.showError()
            }
        }
    }
    
    // MARK: - Update UI
    
    /// Updates the cell based on selection state
    private func updateSelection(cell: UITableViewCell, isSelected: Bool) {
        cell.accessoryType = isSelected ? .checkmark : .none
    }
    
    /// Updates selected ingredients based on selection state
    private func updateSelection(ingredient: Ingredient, isSelected: Bool) {
        if isSelected {
            // 1. If the ingredient was not selected, add it to the selected ingredients.
            selectedIngredients.insert(ingredient)
        } else {
            // 2. Otherwise, remove it from the selected ingredients
            selectedIngredients.remove(ingredient)
        }
    }
    
    /// Shows loading
    private func showLoading(_ show: Bool) {
        // 1. Animate/stop activity indicator
        if show {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
        
        // 2. Enable/disable order button to avoid starting multiple requests for same order
        orderButton.isEnabled = !show
    }
    
    /// Shows error
    private func showError() {
        // 1. Initialize a new alert controller
        let alert = UIAlertController(title: "Order failed!", message: "There was an error ordering your burger.", preferredStyle: .alert)
        
        // 2. Add action to the alert
        let dismissAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
        alert.addAction(dismissAction)
        
        // 3. Present the alert
        present(alert, animated: true, completion: nil)
    }
}
