//
//  SelectionPersistenceService.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/11/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Persists selected ingreients
final class SelectionPersistenceService {
    
    /// Stores data
    private let dataStore: DataStoreProtocol
    
    // MARK: - Initialzers
    
    /// Initializes an instance with 'Networking' as dependency
    init(dataStore: DataStoreProtocol) {
        self.dataStore = dataStore
    }
    
    // MARK: - Persistence
    
    /// Save the selections to data store and return the result of storage operation
    func saveSelectedIngredients(_ ingredients: Set<Ingredient>) -> Bool {
        // 1. Store the ingredients
        let saved = dataStore.storeData(ingredients, forKey: .selectedIngredients)
        
        // 3. Return the result of storage
        return saved
    }
    
    /// Clear selected ingredients saved to the store
    func clearSavedSelectedIngredients() {
        // Either, save an empty list to overwrite the saved data
        _ = saveSelectedIngredients([])
        
        // Or, remove the file
        // if FileManager.default.fileExists(atPath: storagePath) {
        //    _ = try? FileManager.default.removeItem(atPath: storagePath)
        //}
    }
    
    /// Returns the selected ingredients that were stored in the data store
    func loadSelectedIngredients() -> Set<Ingredient>? {
        // 1. Return the decoded ingredients
        return dataStore.retrieveData(forKey: .selectedIngredients)
    }
    
}
