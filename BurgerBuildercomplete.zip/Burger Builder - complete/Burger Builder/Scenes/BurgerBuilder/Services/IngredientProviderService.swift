//
//  IngredientProviderService.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/3/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Provides a list of ingredients to be selected for burger orders
final class IngredientProviderService {
    
    func loadIngredients() -> [Ingredient] {
        return [
            Ingredient(name: "Beef"),
            Ingredient(name: "Chicken"),
            Ingredient(name: "Cheese"),
            Ingredient(name: "Lettuce"),
            Ingredient(name: "Tomato"),
            Ingredient(name: "Caramalized onions"),
            Ingredient(name: "Onion rings"),
            Ingredient(name: "Jalapeños"),
            Ingredient(name: "Mustard"),
            Ingredient(name: "Ketchup"),
            Ingredient(name: "BBQ sauce")
        ]
    }
}
