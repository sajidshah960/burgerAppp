//
//  OrderCreationService.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/9/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Creates new orders
final class OrderCreationService {
    
    /// Sends networking requests
    private let networking: NetworkingProtocol
    
    // MARK: - Initialzers
    
    /// Initializes an instance with 'Networking' as dependency
    init(networking: NetworkingProtocol) {
        self.networking = networking
    }
    
    // MARK: - Order creation
    
    /// Response types for order creation
    enum Response {
        case created
        case failed
    }
    
    /// Places a new order with 'ingredients' and provides response in 'completion'
    func placeOrder(ingredients: Set<Ingredient>, completion: @escaping (Response) -> Void) {
        // 1. Base URL
        guard let baseURL = URL(string: "https://burgerappp-b541b.firebaseio.com/orders.json") else {
            return assertionFailure("Invalid base url")
        }
        
        // 2. HTTP body
        guard let encodedIngredients = try? JSONEncoder().encode(Order(ingredients: Array(ingredients))) else {
            return assertionFailure("Invalid ingredients")
        }
        
        // 3. Send HTTP nethod
        let httpMethod = "POST"
        
        // 4. Send request using data task
        networking.sendHTTPRequest(baseURL: baseURL, method: httpMethod, body: encodedIngredients) { response in
            
            // 5. Handle response
            switch response {
            case .success:
                completion(.created)
                
            case .failure:
                completion(.failed)
            }
            
        }
    }
}
