//
//  DataStoreProtocol.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/17/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Defines data storage functionality
protocol DataStoreProtocol {
    func storeData<T: Codable>(_ encodable: T, forKey key: DataStoreKey) -> Bool
    func retrieveData<T: Codable>(forKey key: DataStoreKey) -> T?
}
