//
//  DataStore.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/9/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Handles data storage, implements 'DataStoreProtocol'.
final class DataStore: DataStoreProtocol {
    
    /// Save to data store at 'key' and return the result of storage operation
    func storeData<T: Codable>(_ encodable: T, forKey key: DataStoreKey) -> Bool {
        // 1. Encode the ingredients to a store compatible type i.e. Data
        guard let encoded = try? JSONEncoder().encode(encodable) else { return false }
        
        // 2. Store the encoded data
        let saved = NSKeyedArchiver.archiveRootObject(encoded, toFile: storagePath(key))
        
        // 3. Return the result of storage
        return saved
    }
    
    /// Returns the data stored at 'key' in the data store
    func retrieveData<T: Codable>(forKey key: DataStoreKey) -> T? {
        // 1. Load saved data from the storage
        guard let encoded = NSKeyedUnarchiver.unarchiveObject(withFile: storagePath(key)) as? Data else { return nil }
        
        // 2. Decode retrieved data into type 'T'
        guard let decoded = try? JSONDecoder().decode(T.self, from: encoded) else { return nil }
        
        // 3. Return the decoded data
        return decoded
    }
    
    /// Path to store the data at
    private func storagePath(_ key: DataStoreKey) -> String {
        // 1. Retrieve URL to the application's documents directory
        let documentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
        
        // 2. Add a path for data inside the documents directory
        let storageURL = documentsDirectory.appendingPathComponent(key.rawValue)
        
        // 3. Return the path
        return storageURL.path
    }
    
}
