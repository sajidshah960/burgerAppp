//
//  Networking.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/9/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Handles networking requests, implements 'NetworkingProtocol'.
final class Networking: NetworkingProtocol {
    
    /// URL session to send URL requests
    private let urlSession: URLSession = .shared
    
    /// Creates and sends http requests
    func sendHTTPRequest(baseURL: URL, method: String, body: Data?, completion: @escaping (NetworkResponse) -> Void) {
        // 1. Create URL request
        var urlRequest = URLRequest(url: baseURL)
        urlRequest.httpMethod = method
        urlRequest.httpBody = body
        
        // 2. Send request using data task
        let task = urlSession.dataTask(with: urlRequest) { (data, response, error) in
            DispatchQueue.main.async {
                if data != nil {
                    completion(.success)
                } else {
                    completion(.failure)
                }
            }
        }
        task.resume()
    }
}
