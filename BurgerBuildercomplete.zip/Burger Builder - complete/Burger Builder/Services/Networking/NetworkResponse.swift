//
//  NetworkResponse.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/11/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Encapsulates a network response 
enum NetworkResponse {
    case success
    case failure
}
