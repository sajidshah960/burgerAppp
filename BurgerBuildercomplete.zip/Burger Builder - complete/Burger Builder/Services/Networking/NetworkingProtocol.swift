//
//  NetworkingProtocol.swift
//  Burger Builder
//
//  Created by Bushra Shahid on 6/17/19.
//  Copyright © 2019 Burger Inc. All rights reserved.
//

import Foundation

/// Defines networking functionality
protocol NetworkingProtocol {
    func sendHTTPRequest(baseURL: URL, method: String, body: Data?, completion: @escaping (NetworkResponse) -> Void)
}
