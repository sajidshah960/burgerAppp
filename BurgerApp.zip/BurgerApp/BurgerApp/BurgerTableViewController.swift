//
//  BurgerTableViewController.swift
//  BurgerApp
//
//  Created by ieX Lab 1_1 on 20/06/2019.
//  Copyright © 2019 ieX Lab 1_1. All rights reserved.
//

import UIKit

class BurgerTableViewController: UITableViewController {
    private let ingredients: [Ingredient] = [
        Ingredient(name: "Beef") ,
        Ingredient(name: "Chicken") ,
        Ingredient(name: "Mutton") ,
        Ingredient(name: "Cheese") ,
        Ingredient(name: "ChickenCheese") ,
    ]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "reuseIdentifier")
        
    }
    private var selectedIngredients: Set<Ingredient> = [] {
        // Reload table view whenever the selected ingredients are updated
        didSet { tableView.reloadData() }
    }     // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 1. Get the selected cell from the table view
        guard let cell = tableView.cellForRow(at: indexPath) else {
            return assertionFailure("Selected cell cannot be nil.")
        }
        /// List of selected ingredients for the burger being built
               // 2. Load the selected ingredient
        let selectedIngredient = ingredients[indexPath.row]
        
        // 3. Find out if the ingredient was added or removed
        let isSelected = !selectedIngredients.contains(selectedIngredient)
        
        // 4. Update UI to reflect the result of addition/removal
        updateSelection(cell: cell, isSelected: isSelected)
        
        // 5. Update the list of selected ingredients to save the change in selection
        updateSelection(ingredient: selectedIngredient, isSelected: isSelected)
        
        // 6. Deselect the cell from the table view
        tableView.deselectRow(at: indexPath, animated: true)
    }
    // Update the cell based on selection state
    private func updateSelection(cell: UITableViewCell, isSelected: Bool) {
        cell.accessoryType = isSelected ? .checkmark : .none
    }
    
    /// Update selected ingredients based on selection state
    private func updateSelection(ingredient: Ingredient, isSelected: Bool) {
        if isSelected {
            // 1. If the ingredient was not selected, add it to the selected ingredients.
            selectedIngredients.insert(ingredient)
        } else {
            // 2. Otherwise, remove it from the selected ingredients
            selectedIngredients.remove(ingredient)
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ingredients.count
        // #warning Incomplete implementation, return the number of rows
        //return 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...
        let ingredient = ingredients[indexPath.row]
        cell.textLabel?.text = ingredient.name
        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
