//
//  File.swift
//  BurgerApp
//
//  Created by ieX Lab 1_1 on 20/06/2019.
//  Copyright © 2019 ieX Lab 1_1. All rights reserved.
//

import Foundation

struct Ingredient: Hashable , Codable
{
    let name : String
}
